clc
clear

g  = figure;

%% Import Example_Calcium_data

%col1: Inscopix time
%col2~: each col is a Calcium trace from a single neuron




Ca = readtable('Example_Calcium_data.csv');

Cells = table2array(Ca);

CellTime = Cells(:,1); % Inscopix clock



subplot(3,4,[1 3])
for i = 1:size(Cells,2)-1
plot(CellTime,Cells(:,1+i),'.')
hold on
plot(CellTime,Cells(:,1+i),'k-')


end

xlabel('Inscopix time (s)')
title('Calcium data')


subplot(3,4,4)
c = size(CellTime,1);
bar(c)
ylim([0 20000])
title('Number of datapoints')
set(gca,'xtick',[])

%% Open ethovision behavioral data


Trial = readtable('Ethovision_behavioral_data.csv');


EthoTime = Trial.RecordingTime; % Ethovision clock (from begining of tracking)

subplot(3,4,[5 7])
plot(EthoTime, Trial.Sniffing,'.')
hold on
plot(EthoTime, Trial.Reciprocal_sniffing+1.5,'.')
plot(EthoTime, Trial.Sniffing,'k-')
plot(EthoTime, Trial.Reciprocal_sniffing+1.5,'k-')

set(gca,'ytick',[])
ylim([-1 3])
box off

xlabel('Ethovision time (s)')
title('Example behavior vectors')
legend('Sniffing','Reciprocal Sniffing')




subplot(3,4,8)
c = size(EthoTime,1);
bar(c)
ylim([0 20000])
title('Number of datapoints')
set(gca,'xtick',[])



%% IntegrateDaTa aligned to Calcium data


a=EthoTime;

AdjBehavior = [];

k= table2array(Trial);
k = k(:,3:end);
 


for i = 1:length(CellTime)
    
n = CellTime(i);
[val,idx]=min(abs(a-n));
minVal=a(idx);


XYI = [minVal k(idx,:)];
AdjBehavior = [AdjBehavior; XYI];


end

AdjBehavior = [CellTime AdjBehavior];


Labels = Trial.Properties.VariableNames;
Labels{1} = 'InscopixTime';
Labels{2} = 'EthovisionTime';

T = array2table(AdjBehavior, 'VariableNames',Labels); % Downsampled and temporally aligned behavioral data (to Inscopix time)

%%

subplot(3,4,[9 11])
plot(CellTime, T.Sniffing,'.')
hold on
plot(CellTime, T.Reciprocal_sniffing+1.5,'.')
plot(CellTime, T.Sniffing,'k-')
plot(CellTime, T.Reciprocal_sniffing+1.5,'k-')

for i = 1:size(Cells,2)-1
plot(CellTime,Cells(:,1+i),'.')
hold on
plot(CellTime,Cells(:,1+i),'k-')


end


set(gca,'ytick',[])
ylim([-1 10])
box off

xlabel('Inscopix time (s)')
title('Example behavior vectors')
legend('Sniffing','Reciprocal Sniffing')




subplot(3,4,12)
c = size(CellTime,1);
bar(c)
ylim([0 20000])
title('Number of datapoints')
set(gca,'xtick',[])




%% save results in result folder
curr = cd;
mkdir('Result')
cd(strcat(curr,'\Result'))

writetable(T,'Aligned_Behavior.xls')
save('Cells.mat','Cells')

